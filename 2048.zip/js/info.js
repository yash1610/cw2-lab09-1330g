//loadds the instruction content by default
window.onload = changeInfo("instruction");

//changes dynamically the content of the page
function changeInfo(info) {
    var instruction = " \
        <ol> \
            <li>Start with an initial board. The game will give you an initial 4x4 board, \
                totaling 16 tiles. Two tiles of 2 will be placed at random positions on the board.</li> \
            <li>Move tiles. In the commnad line type next commands: up, down, left, and right \
                and press enter to move the tiles across the board. \
                The tiles will slide towards the other end, as long as there’s available space.</li> \
            <li>Merge tiles. When tiles of the same number touch during a move, \
                they will combine into one tile carrying the sum of the two tiles.</li> \
            <li>Get additional tile. On every move, whether you were able to merge 2 tiles or not, \
                a new tile of 2 or 4 will randomly appear on the board. \
                This is how you get new tiles and numbers in play.</li> \
            <li>Continue merging tiles. Continue moving the tiles across the board to increase the numbers on the tiles. \
                The objective is to reach get a 2048 tile on the board. This get be achieved by combining two 1024 tiles, \
                coming from two 512 tiles, merged from two 256 tiles, and so on.</li> \
            <li>Finish the game. The game ends when the board is completely filled with numbered tiles \
                and there’s no move available.</li> \
        </ol>";

    var tips = " \
        <ol> \
            <li>Don’t rush. There’s no time limit to the game. Play each move slowly and consider all options before sliding tiles.</li> \
            <li>Move tiles to the bottom. Focus your tiles on the bottom corners.  \
                Having new tiles appear on top will make it easier for you to move and merge them.</li> \
            <li>Create a pattern. If you like patterns, try to build one with the numbered tiles.  \
                Have the larger numbered tiles on the bottom to the right or left, followed by  \
                decreasing numbered tiles on the next rows. This way, you can easily merge the tiles when you reach the matching numbers.</li> \
            <li>Don’t move the largest tile. Once you’ve gotten the largest numbered tile on one corner, don’t move it.  \
                Moving the other larger tiles to merge with this one will be much easier.</li> \
            <li> Don’t move up. You can easily get a high score or even reach the 2048 tile by not moving or swiping up.  \
                Just move or swipe left, right, and bottom, and you’ll be fine.</li> \
        </ol>";

    var about = "2048 is a single-player sliding block puzzle game designed by Italian web developer Gabriele Cirulli. \
        The game's objective is to slide numbered tiles on a grid to combine them to create a tile with the number 2048. However,  \
        one can continue to play the game after reaching the goal, creating tiles with larger numbers. <br><br>\
        2048 was originally written in JavaScript and CSS during a weekend, and released on March 9, 2014, as free  \
        and open-source software subject to the MIT license. Clones written in C++ and Vala are available. \
        There is also a version for the Linux terminal. <br><br> \
        2048 has been described as very similar to the Threes! app released a month earlier. \
        Cirulli himself described 2048 as a clone of Veewo Studios' app 1024, who has actually said \
        in the description of the app to be a clone of Threes!.";

    setBoxShadowToNone();
    
    switch(info){
        case "instruction": {
            document.getElementById("content").innerHTML = instruction;             
            document.getElementById("instruction").style.boxShadow = "inset 0px 0px 5px 5px rgb(114, 43, 2)";
            break;
        }
        case "tips": {
            document.getElementById("content").innerHTML = tips; 
            document.getElementById("tips").style.boxShadow = "inset 0px 0px 5px 5px rgb(114, 43, 2)";
            break;
        }
        case "about": {
            document.getElementById("content").innerHTML = about; 
            document.getElementById("about").style.boxShadow = "inset 0px 0px 5px 5px rgb(114, 43, 2)";
            break;
        }
    }
}

//resets all the option elements to unchosen
function setBoxShadowToNone(){
    document.getElementById("instruction").style.boxShadow = "none";
    document.getElementById("tips").style.boxShadow = "none";
    document.getElementById("about").style.boxShadow = "none";
}
