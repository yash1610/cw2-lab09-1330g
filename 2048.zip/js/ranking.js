window.onload = tableGenerator();

//generates the ranking table
function tableGenerator(){
    var scores = [];
    var keys = Object.keys(localStorage);
    var table = document.getElementById("ranking-table");
    var loggedInUser = localStorage.loggedInUser;    

    //stores all users data into the scores array
    for(var i = 0; i < keys.length; i++)
        if(keys[i] !== "loggedInUser")
            scores[i] = JSON.parse(localStorage[keys[i]]);    

    //sorts the users by their score, descending
    scores.sort(function(user1, user2) {
        return user2.best - user1.best;
    });

    table.innerHTML = "<table id = 'ranking'> <tr><th>Rank<th style = 'min-width: 300px;'>Player</th><th>Score</tr>"

    //for each user is added a row with its rank position, username and score    
    for(var i = 0; i < scores.length; i++){
        var row = document.createElement("tr");
        var rank = document.createElement("td");
        var player = document.createElement("td");
        var scoring = document.createElement("td");

        //if there is a logged in user then its row is bolded
        if(loggedInUser !== undefined && scores[i].username === loggedInUser){
            row.style.fontWeight = "bold";
        } 

        rank.innerHTML = i + 1;
        player.innerHTML = scores[i].username;
        scoring.innerHTML = scores[i].best;
        
        row.appendChild(rank);
        row.appendChild(player);
        row.appendChild(scoring);

        document.getElementById("ranking").appendChild(row);
    }
    table.innerHTML += "</table>";
}