window.onload = checkUser(); 

//checks if there is any logged in user, 
//if yes the game starts, otherwise it asks the user to login or register
function checkUser(){
    var loggedInUser = localStorage.loggedInUser;
    if(loggedInUser === undefined){
        document.getElementById("gameArea").style.display = "none";
        document.getElementById("gameCover").style.display = "block";
    } else {
        document.getElementById("gameCover").style.display = "none";        
        document.getElementById("gameArea").style.display = "block";
        start();
    }        
}

//generates the game table with the elements same as last played game
//or sets a new board once the user pressed the NEW GAME button
function start(){  
    window.score = 0;
    var user = JSON.parse(localStorage[localStorage.loggedInUser]);
    window.table = user.table;
    var newGame = true;

    if(document.getElementById("element00") == null){
        for(var i = 0; i < 4; i++)
            for(var j = 0; j < 4; j++){  
                if(window.table[i][j] !== 0) 
                    newGame = false;
                var element = document.createElement("span");
                element.setAttribute("id", "element" + i + "" + j);
                element.style.cursor = "default";
                element.style.userSelect = "none";
                document.getElementById("table").appendChild(element);
                setColor(window.table[i][j], i, j);
                window.score = user.score;       
                document.getElementById("current").innerHTML = window.score;         
            }     
        if(newGame){
            addNew();
            addNew();
        }            
    } else {
        for(var i = 0; i < 4; i++)
            for(var j = 0; j < 4; j++){
                window.table[i][j] = 0;
                setColor(window.table[i][j], i, j);
            }                
        document.getElementById("current").innerHTML = window.score;        
        addNew();
        addNew();
    }  

    document.getElementById("best").innerHTML = user.best;           

    document.getElementById("do").addEventListener("click", function(){ update(); });

    //makes the pressed enter key to do the same action as the button do
    document.getElementById("commandLine").addEventListener("keyup", function(event) {
        event.preventDefault();
        if (event.keyCode === 13) {
            document.getElementById("do").click();
        }
    });
}

//retrieves the command from the input and executes the corresponding move
function update(){
    var direction = document.getElementById("commandLine");
    direction.placeholder = "";
    
    switch(direction.value.toLowerCase()){
        case "up": up(); break;
        case "down": down(); break;
        case "right": right(); break;
        case "left": left(); break;
        default: 
            direction.placeholder = "Invalid Command";
    }
    document.getElementById("commandLine").value = "";
    document.getElementById("commandLine").focus();
}

//each retrieved command has a move function which moves all the tiles on the board in the given direction
//each move function returns the number of moves in order to limit the creation of a new tile if there were no tiles moved

function up(){    
    var moves = 0;
    for(var k = 0; k < 3; k++)
        moves = moveUp(moves);

    //merges tiles with the same value and on the same column
    for(var i = 1; i < 4; i++)
        for(var j = 0; j < 4; j++)
            if(window.table[i][j] === window.table[i-1][j] && window.table[i][j] !== 0){
                moves++;
                window.table[i-1][j] *= 2;
                window.table[i][j] = 0;
                setColor(window.table[i-1][j], i-1, j);
                setColor(window.table[i][j], i, j);
                scoring(window.table[i-1][j]);
            }             
    moves = moveUp(moves);
    
    if(moves !== 0)
        addNew();
}

function moveUp(moves){
    for(var i = 3; i >= 0; i--)
        for(var j = 3; j >= 1; j--)
            if(window.table[j][i] !== 0)
                if(window.table[j-1][i] === 0){
                    moves++;
                    window.table[j-1][i] = window.table[j][i];
                    window.table[j][i] = 0;
                    setColor(window.table[j][i], j, i);
                    setColor(window.table[j-1][i], j-1, i);
                }
    return moves;
}

function down(){    
    var moves = 0;
    for(var k = 0; k < 3; k++)
        moves = moveDown(moves);
        
    //merges tiles with the same value and on the same column
    for(var i = 2; i >= 0; i--)
        for(var j = 3; j >= 0; j--)
            if(window.table[i][j] === window.table[i+1][j] && window.table[i][j] !== 0){
                moves++;
                window.table[i+1][j] *= 2;
                window.table[i][j] = 0;
                setColor(window.table[i+1][j], i+1, j);
                setColor(window.table[i][j], i, j);
                scoring(window.table[i+1][j]);
            }             
    moves = moveDown(moves);

    if(moves !== 0)
        addNew();
}

function moveDown(moves){
    for(var i = 0; i < 4; i++)
        for(var j = 0; j < 3; j++)
            if(window.table[j][i] !== 0)
                if(window.table[j+1][i] === 0){
                    moves++;
                    window.table[j+1][i] = window.table[j][i];
                    window.table[j][i] = 0;
                    setColor(window.table[j][i], j, i);
                    setColor(window.table[j+1][i], j+1, i);
                }
    return moves;
}

function right(){
    var moves = 0;
    for(var k = 0; k < 3; k++)
        moves = moveRight(moves);
        
    //merges tiles with the same value and on the same row
    for(var i = 3; i >= 0; i--)
        for(var j = 2; j >= 0; j--)
            if(window.table[i][j] === window.table[i][j+1] && window.table[i][j] !== 0){
                moves++;
                window.table[i][j+1] *= 2;
                window.table[i][j] = 0;
                setColor(window.table[i][j+1], i, j+1);
                setColor(window.table[i][j], i, j);
                scoring(window.table[i][j+1]);
            }            
    moves = moveRight(moves);

    if(moves !== 0)
        addNew();
}

function moveRight(moves){
    for(var i = 0; i < 4; i++)
        for(var j = 0; j < 3; j++)
            if(window.table[i][j] !== 0)
                if(window.table[i][j+1] === 0){
                    moves++;
                    window.table[i][j+1] = window.table[i][j];
                    window.table[i][j] = 0;
                    setColor(window.table[i][j], i, j);
                    setColor(window.table[i][j+1], i, j+1);
                }
    return moves;
}

function left(){
    var moves = 0;
    for(var k = 0; k < 3; k++)
        moves = moveLeft(moves);

    //merges tiles with the same value and on the same row
    for(var i = 0; i < 4; i++)
        for(var j = 1; j < 4; j++)
            if(window.table[i][j] === window.table[i][j-1] && window.table[i][j] !== 0){
                moves++;
                window.table[i][j-1] *= 2;
                window.table[i][j] = 0;
                setColor(window.table[i][j-1], i, j-1);
                setColor(window.table[i][j], i, j);
                scoring(window.table[i][j-1]);
            }   
    moves = moveLeft(moves);

    if(moves !== 0)
        addNew();
}

function moveLeft(moves){
    for(var i = 3; i >= 0; i--)
        for(var j = 3; j >= 1; j--)
            if(window.table[i][j] !== 0)
                if(window.table[i][j-1] === 0){
                    moves++;
                    window.table[i][j-1] = window.table[i][j];
                    window.table[i][j] = 0;
                    setColor(window.table[i][j], i, j);
                    setColor(window.table[i][j-1], i, j-1);
                }
    return moves;
}

//changes the scoring in the user's local storage record and displays it 
//saves in the local storage the current state of the game
function scoring(scoreToAdd){
    window.score += scoreToAdd;
    var user = JSON.parse(localStorage[localStorage.loggedInUser]);
    document.getElementById("current").innerHTML = window.score;
    user.score = window.score;
    user.table = window.table;
    if(window.score > document.getElementById("best").innerHTML){
        document.getElementById("best").innerHTML = window.score;
        user.best = window.score;        
    }       
    localStorage.setItem(user.username, JSON.stringify(user));    
}

//adds a new tile on the game board on a randomly selected empty cell
function addNew(){
    var randomX = Math.floor(Math.random() * 4);
    var randomY = Math.floor(Math.random() * 4);
    var first = Math.random();

    while(window.table[randomX][randomY] != 0){
        randomX = Math.floor(Math.random() * 4);
        randomY = Math.floor(Math.random() * 4);
    }

    if(first < 0.86){
        window.table[randomX][randomY] = 2;
        setColor(2, randomX, randomY);
    } else {
        window.table[randomX][randomY] = 4;
        setColor(4, randomX, randomY);
    }

    var user = JSON.parse(localStorage[localStorage.loggedInUser]);
    user.table = window.table;
    localStorage.setItem(user.username, JSON.stringify(user));
}

//returns the colour that corresponds to the value of the generated tile
function changeColor(value){
    switch(value){
        case 0: return "rgb(205, 193, 180)";
        case 2: return "rgb(238, 228, 218)";  
        case 4: return "rgb(237, 224, 200)";  
        case 8: return "rgb(242, 177, 121)";  
        case 16: return "rgb(245, 149, 99)";
        case 32: return "rgb(246, 124, 95)";
        case 64: return "rgb(246, 94, 59)";
        case 128: return "rgb(237, 207, 114)";
        case 256: return "rgb(237, 204, 97)";
        case 512: return "rgb(237, 200, 80)";
        case 1024: return "rgb(237, 197, 63)";
        case 2048: return "rgb(237, 194, 46)";
        default: return "rgb(60, 58, 50)";
    }
}

//changes the content and colour of a tile
function setColor(value, row, column){
    var id = "element" + row + "" + column;

    //the 0 value is considered an empty cell
    if(value === 0)
        document.getElementById(id).innerHTML = "";
    else
        document.getElementById(id).innerHTML = value;
    document.getElementById(id).style.backgroundColor = changeColor(value);

    if(value > 4)
        document.getElementById(id).style.color = "white";
    else
        document.getElementById(id).style.color = "#776e65";

    //changes the font size of the number of hte tile to make it to fit in
    if(value > 100)
        document.getElementById(id).style.fontSize = "3.5em";
    else if(value > 1000)
        document.getElementById(id).style.fontSize = "3em";
    else 
        document.getElementById(id).style.fontSize = "4em";
}