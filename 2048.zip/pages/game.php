<?php
    include('../php/common.php');
    head('Game');
?>

    <!-- Header -->

    <?php
        menu('Game');
    ?>

    <!-- Game area-->

    <div class="full-width-item" id = "gameCover">
        <p>Please
        <a href = "index.php"> Login/Register</a>
        to play the game</p>
    </div>

    <article class="full-width-item" id = "gameArea">
        <table class = "score">
            <tr>
                <th>Score</th>
                <th>Best</th>
            </tr>
            <tr>
                <td id = "current">0</td>
                <td id = "best">0</td>
            </tr>
        </table>

        <button type = "button" id = "newGame" onclick = "start()">New Game</button>

        <div id = "table">
        </div>

        <center><p><b>Commands</b>: UP, DOWN, LEFT, RIGHT. 
        <br>Press ENTER or DO button to execute.</p></center>
        <center><input type = "text" id = "commandLine" autofocus/>
        <button type = "button" id = "do">DO</button> </center>
    </article>

     <script src = "../js/game.js"></script>

<?php
    footer()
?>