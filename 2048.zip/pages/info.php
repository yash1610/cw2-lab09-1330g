<?php
    include('../php/common.php');
    head('Info');
?>

    <!-- Header -->

    <?php
        menu('Info');
    ?>

    <!-- Information page devided into right menu with options 
        and left side with related to chosen menu item content 
        by default chosen first item-->   

    <article id="info-item" class="full-width-item">     
        <div id="info-nav">
            <ul>
                <li id = "instruction" onclick = "changeInfo('instruction')">How to play</li>
                <li id = "tips" onclick = "changeInfo('tips')">Tips</li>
                <li id = "about" onclick = "changeInfo('about')">About</li>
            </ul>
        </div>
        <div id="content">
            <!-- Content of the chosen info option -->
        </div>
    </article>

     <script src = "../js/info.js"></script>

<?php
    footer()
?>