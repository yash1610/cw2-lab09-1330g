<?php
    include('../php/common.php');
    head('Ranking');
?>

    <!-- Header -->

    <?php
        menu('Ranking');
    ?>

    <!-- Ranking table -->

    <article class="full-width-item">
        <div id="ranking-table">
        </div>
    </article>

    <script src = "../js/ranking.js"></script>
    
<?php
    footer()
?>