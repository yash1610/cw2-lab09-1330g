<?php
    include('../php/common.php');
    head('Main');
?>

    <!-- Header -->

    <?php
        menu('Main');
    ?>

    <!-- log in / registration form,
        registration form hidden by default
        fixed position -->

    <aside class="grid-item">

        <script src="../js/formsChange.js"></script>
        <script src="../js/validation.js"></script>

        <p id = "error"></p>

        <!--log in form-->
        
        <form id = "login" onsubmit="return isLogInValid()">
            <input type="text" placeholder="Username" id = "username" autofocus required/>           
            <input type="password" placeholder="Password" id = "passwd" required/>
            <button type="submit">Log in</button>
            <center>
                <p style="font-weight: bold; font-size: 1.5rem;">Don't have an account?</p>
            </center>          
            <button type="button" onclick="changeToRegister()">Register</button>              
        </form>
            
        <!--registration form-->
        <form id="register" onsubmit="return isRegisterValid()">
            <input type="text" placeholder="Username" id = "usernameReg" autofocus required/>
            <input type="password" placeholder="Password" id = "passwdReg" required/>
            <input type="password" placeholder="Repeat Password" id = "passwdRepeat" required/>
            <input type="email" placeholder="Email" id = "email" required/>
            <button type="submit">Register</button>
            <center>
                <p style="font-weight: bold; font-size: 1.5rem;">Already have an account?</p>
            </center> 
            <button type="button" onclick="changeToLogin()">Log in</button>
        </form>

        <!--information for the logged in user-->
        <div id = "userInfo">
            <p id = "loggedInUser"></p>
            <table class = "score" style = "float:none; width: 100%">
                <tr>
                    <th>Last game</th>
                    <th>Best</th>
                </tr>
                <tr>
                    <td id = "last">0</td>
                    <td id = "bestScore">0</td>
                </tr>
            </table>
            <button type = "button" id = "new">New game</button>
            <button type = "button" id = "continue">Continue game</button>
            <button type = "button" id = "logout">Log out</button>
        </div>     
    </aside>

    <script src = "../js/pageLoad.js"></script>

    <!-- Item containing a game demo and description
     all positioned in the centre -->

    <article class="grid-item", style="padding:20px">
        <video controls>
            <source src="../video/demo.mp4">
            Your browser does not support the video tag.
        </video>

        <h2>Description:</h2>
        <section>
            <p style="font-size: 1.2em; text-align: justify;">
                <strong>2048</strong> masters the line of strategy and luck.<br>
                The goal is to join numbers to get the 2048 tile.<br>
                When two tiles with the same number touch, they merge into one.<br>
                Continue to play the game to be the first in ranking!</p>
        </section>        

        <h2>Facts:</h2>
        <section>            
            <ul style="padding-left: 20px; text-align: justify; font-size: 1.2em; ">
                <li style="
                margin-bottom: 10px">2048 was created as a weekend project by a 19-year-old
                    Gabriele Cirulli</li>
                <li style="
                margin-bottom: 10px">It has been played over 51 million times,
                    out of which only 530,000 have resulted in a win.</li>
                <li style="
                margin-bottom: 10px">The creator has never been able to beat the game. Yes,
                    no joke.
                    “I still haven’t managed it!”.</li>
            </ul>
        </section>

        <p style="font-size: 1.7em; text-align: center;"><b>Log in</b> or <b>Register</b> to play</p>
    </article>

    <!-- Left side item 
        fixed position  -->

    <aside class="grid-item">
        <div id="threes-parent">
            <h2 style="text-align: center; font-size: 2em; margin-top: 5px;">AWESOME AND CHALLENGING puzzle game</h3>
                <ul id="threes">
                    <li style="background-color: rgb(235, 202, 96); box-shadow: 0px 0px 15px 9px rgb(235, 202, 96)">Have
                        fun</li>
                    <li style="background-color: rgb(141, 124, 110); box-shadow: 0px 0px 15px 9px rgb(141, 124, 110)">Train
                        your brain</li>
                    <li style="background-color: rgb(254, 61, 60); box-shadow: 0px 0px 15px 9px rgb(254, 61, 60)">Achieve
                        the highest score</li>
                </ul>
        </div>

    </aside>

<?php
    footer()
?>