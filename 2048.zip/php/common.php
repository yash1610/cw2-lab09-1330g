<?php

    //Generates the head changing the title of each page
    function head($title) {
        print(
        '<!DOCTYPE html>
        <html lang="en-GB">
            <head>
                <meta charset="UTF-8">
                <title>'.$title.'</title>
                <link rel="stylesheet" type="text/css" href="../css/theme.css">
                <link rel="icon" href="../img/icon.png">
            </head>
            <body>');
    }


    //Generates the menu changing the active ite
    function menu($current_page) {
        print('
        <span class="item-logo">
            <img src="../img/logo.png" alt="Game name">
        </span>
        <nav class="item-nav">
            <ul>');

        //arrays of menu items and their links
        $link_names = array('Main', 'Game', 'Info', 'Ranking');
        $link_addresses = array('index.php', 'game.php', 'info.php', 'ranking.php');

        //a loop that iterates through menu names array showing them and 
        for($i = 0; $i < count($link_names); $i++){
            echo '<li><a ';
            if($link_names[$i] == $current_page)
                echo 'class = "active" ';
            echo 'href='.$link_addresses[$i].'>'.$link_names[$i].'</a></li>';
        }        
                
        print(
            '</ul>
        </nav>');

    }

    //Generates the footer
    function footer(){
        print('
                <footer class="grid-item">
                    <p>Developed by Cristina Tincu <br> Middlesex University <br> Web Applications and Databases Module</p>
                </footer>        
            </body>
        </html>');
    }

?>